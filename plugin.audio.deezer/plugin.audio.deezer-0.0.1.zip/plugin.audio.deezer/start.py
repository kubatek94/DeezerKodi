from resources.lib.Scenes.SceneRouter import SceneRouter

sceneRouter = SceneRouter()
sceneRouter.route(sys.argv)

del sceneRouter