from kodi.event import EventSubscriber
from kodi.events import KernelEvents
from deezer.src.views.security import AskCredentialsResponse


class LoginGatewaySubscriber(EventSubscriber):
    def get_events(self):
        return [(KernelEvents.REQUEST, self.verify_credentials)]

    def verify_credentials(self, event):
        logged_in = True
        if not logged_in:
            event.set_response(AskCredentialsResponse())