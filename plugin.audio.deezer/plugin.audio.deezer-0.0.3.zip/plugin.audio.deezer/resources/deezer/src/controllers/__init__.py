from kodi.controller import Controller
from kodi.response import Response

class DemoController(Controller):
    def index(self):
        print 'Index route'
        return Response()

    def tracks(self, track_id):
        print "Play track %s" % track_id
        return Response()

    def view_user_playlist(self, user_id, playlist_id):
        print "Open playlist %s from user %s" % (playlist_id, user_id)
        return Response()