from kodi.response import Response
from kodi import xbmc

class AskCredentialsResponse(Response):
    def send(self):
        xbmc.notify("Enter your credentials in settings first")