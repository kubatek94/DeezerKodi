from service import ContainerAwareInterface
import re
_pattern_re = re.compile(r'(?P<static>[^<]*)<?(?P<variable>[a-zA-Z_]*)>?')
_pattern_reverse_re = re.compile(r'<(?P<var>[A-Za-z_]*)>')


def compile_pattern(pattern):
    regex = []
    for m in _pattern_re.finditer(pattern):
        static = m.group('static')
        if static:
            regex.append(re.escape(static))
        var = m.group('variable')
        if var:
            regex.append('(?P<%s>[^/]+?)' % var)
    return re.compile(r'^%s$' % (''.join(regex)))


class RouteNotFoundError(Exception):
    pass


class UrlMatcher(ContainerAwareInterface):
    def __init__(self, routes):
        self.routes = routes

    def add_route(self, name, pattern, target):
        class_path = target.__module__.split('.')[-1] + ':' + target.__name__
        self.routes[name] = {'pattern': pattern, 'target': class_path}

    def match(self, url):
        for name, route in self.routes.iteritems():
            if 'regex' not in route:
                route['regex'] = compile_pattern(route['pattern'])
            elif isinstance(route['regex'], basestring):
                route['regex'] = re.compile(route['regex'])
            match = route['regex'].search(url)
            if match:
                kwargs = match.groupdict()
                return (route, kwargs)
        raise RouteNotFoundError("No route for url: %s" % url)

    def url_for(self, name, **kwargs):
        if name not in self.routes:
            raise RouteNotFoundError("No route with name: %s" % name)
        return _pattern_reverse_re.sub(lambda m: str(kwargs[m.group('var')]), self.routes[name]['pattern'])

    def route(self, pattern, name):
        def route_decorator(f):
            self.add_route(pattern, name, target=f)
            def f_wrapper(*args, **kwargs):
                return f(args, kwargs)
            return f_wrapper
        return route_decorator