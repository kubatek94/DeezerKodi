from ..event import Event


class KernelEvents(object):
    REQUEST = 'kernel.request'
    RESPONSE = 'kernel.response'
    CONTROLLER_AND_ARGUMENTS = 'kernel.controller_arguments'


class GetResponseEvent(Event):
    def __init__(self, kernel, request):
        super(GetResponseEvent, self).__init__(KernelEvents.REQUEST)
        self._kernel = kernel
        self._request = request
        self._response = None

    def has_response(self):
        return self._response is not None

    def get_response(self):
        return self._response

    def set_response(self, response):
        self._response = response
        self.stop_propagation()


class FilterResponseEvent(Event):
    def __init__(self, kernel, request, response):
        super(FilterResponseEvent, self).__init__(KernelEvents.RESPONSE)
        self._kernel = kernel
        self._request = request
        self._response = response

    def get_response(self):
        return self._response


class FilterControllerAndArgumentsEvent(Event):
    def __init__(self, kernel, request, controller, arguments):
        super(FilterControllerAndArgumentsEvent, self).__init__(KernelEvents.CONTROLLER_AND_ARGUMENTS)
        self._kernel = kernel
        self._request = request
        self._controller = controller
        self._arguments = arguments

    def get_controller(self):
        return self._controller

    def get_arguments(self):
        return self._arguments
