# KodiFramework
This is a framework for Kodi addon developers greatly inspired by (PHP) Symfony framework.
It provides support for routing, controllers, events, requests & responses, dependency injection and deployment configuration.

# Demo
You can unpack the `plugin.audio.demoapp.zip` in order to see the framework in action.
Go into `plugin.audio.demoapp` and run `./addon.py addon://plugin.audio.demoapp/tracks/1234 0 ''`