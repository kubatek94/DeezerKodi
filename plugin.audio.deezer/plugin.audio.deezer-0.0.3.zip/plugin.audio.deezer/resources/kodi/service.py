try:
    import importlib
except ImportError:
    import kodi.importlib as importlib

class ServiceContainer(object):
    def __init__(self, store):
        self._store = store

    def _translate_parameter(self, key):
        if key.startswith('%') and key.endswith('%'):
            return self.get_parameter(key[1:len(key)-1])
        elif key.startswith('@'):
            return self.get_service(key[1:])
        else:
            return key

    def get_service(self, service_name):
        services = self._store['services']
        if service_name in services:
            service = services[service_name]
            if isinstance(service, dict):
                arguments = map(self._translate_parameter, service.get('arguments', []))
                class_path = service['class'].split(':')
                service_instance = Service.create_from(class_path[0], class_path[1], arguments)

                map(
                    lambda call:
                        getattr(service_instance, call[0])(
                            *(map(self._translate_parameter, call[1]))
                        ),
                    service.get('calls', [])
                )

                service_instance.set_container(self)
                services[service_name] = service_instance
                return service_instance
            else:
                return service
        return None

    def get_services(self):
        services = self._store['services'].values()
        return filter(lambda s: isinstance(s, Service), services)

    def set_service(self, service_name, service):
        service.set_container(self)
        self._store['services'][service_name] = service

    def get_parameter(self, parameter_name):
        return self._store['parameters'][parameter_name]

    def set_parameter(self, parameter_name, parameter_value):
        self._store['parameters'][parameter_name] = parameter_value

    def __getitem__(self, item):
        return self._store[item]


class ContainerAwareInterface(object):
    def set_container(self, service_container):
        self._service_container = service_container

    def get_container(self):
        return self._service_container

    def get(self, service_name):
        return self._service_container.get_service(service_name)


class Service(ContainerAwareInterface):
    @classmethod
    def create_from(cls, _module, _class, arguments):
        service = getattr(importlib.import_module(_module), _class)
        return service(*arguments)

    def _stop(self):
        pass