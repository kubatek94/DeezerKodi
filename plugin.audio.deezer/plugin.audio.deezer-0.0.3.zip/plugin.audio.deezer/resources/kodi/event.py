from service import ContainerAwareInterface


class Event(object):
    def __init__(self, subject, arguments=None):
        self._should_propagate = True
        self._subject = subject
        self._arguments = arguments or {}

    def stop_propagation(self):
        self._should_propagate = False

    def is_propagation_stopped(self):
        return not self._should_propagate


class EventSubscriber(ContainerAwareInterface):
    def get_events(self):
        raise Exception('Get events needs to be implemented')


class EventDispatcher(ContainerAwareInterface):
    def __init__(self):
        self._listeners = {}
        self._closed = False

    def dispatch(self, event_name, event):
        if not self._closed:
            for e, listeners in self._listeners.items():
                listeners.sort(key=lambda l: l['priority'])
            self._closed = True

        if event_name in self._listeners:
            for listener in self._listeners[event_name]:
                if event.is_propagation_stopped(): break

                target = listener['target']

                if isinstance(target, str):
                    target = self.get(target)
                    target(event)
                elif callable(target):
                    target(event)
                else:
                    raise Exception("Event listener is not supported")

    def add_listener(self, event_name, target, priority=0):
        listeners = self._listeners.get(event_name, [])
        self._listeners[event_name] = listeners
        listeners.append({
            'target': target,
            'priority': priority
        })

    def add_subscriber(self, subscriber):
        map(lambda listener: self.add_listener(listener[0], listener[1]), subscriber.get_events())
