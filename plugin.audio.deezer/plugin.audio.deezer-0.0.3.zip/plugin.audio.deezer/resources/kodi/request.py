import sys
import urlparse


class Request(object):
    def __init__(self, url, request_id, args):
        self._url = url

        parts = urlparse.urlparse(url)

        self._scheme = parts.scheme
        self._host = parts.netloc
        self._path = parts.path
        self._params = parts.params
        self._query = parts.query
        self._fragment = parts.fragment

        self._id = request_id
        self._args = args
        self._attributes = {}

    def get_id(self):
        return self._id

    def get_path(self):
        return self._path

    def get_query(self):
        return self._query

    def get_params(self):
        return self._params

    def get_attributes(self):
        return self._attributes

    @classmethod
    def create_from_globals(cls):
        return Request(sys.argv[1], sys.argv[2], urlparse.parse_qs(sys.argv[3]))