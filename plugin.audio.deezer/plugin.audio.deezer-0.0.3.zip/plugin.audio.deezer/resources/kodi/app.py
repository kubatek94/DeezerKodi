from service import ServiceContainer

class App(object):
    def __init__(self):
        self.config = None
        self.container = None

    def boot(self, config, bundles):
        self.config = config
        self.container = ServiceContainer(config)
        map(lambda bundle: bundle.register(self), bundles)

    def handle(self, request):
        pass

    def terminate(self, request, response):
        map(lambda service: service._stop(), self.container.get_services())