class Response(object):
    def __init__(self):
        self._success = True

    def is_success(self):
        return self._success

    def send(self):
        pass
