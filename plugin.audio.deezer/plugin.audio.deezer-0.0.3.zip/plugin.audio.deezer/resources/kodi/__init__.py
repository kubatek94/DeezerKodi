import os
from config import YamlConfigLoader

try:
    import xbmc
    import xbmcgui
    import xbmcaddon
    import xbmcplugin
except ImportError:
    import mock.xbmc as xbmc
    import mock.xbmcgui as xbmcgui
    import mock.xbmcaddon as xbmcaddon
    import mock.xbmcplugin as xbmcplugin


def get_config(app):
    loader = YamlConfigLoader(app)
    return loader.load_config(os.path.abspath(os.path.join(__path__[0], 'plugin/config.yml')))


def register(app):
    pass