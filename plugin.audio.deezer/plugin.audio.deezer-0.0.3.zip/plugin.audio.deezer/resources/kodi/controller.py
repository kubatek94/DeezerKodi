import importlib
from service import ContainerAwareInterface


class Controller(ContainerAwareInterface):
    pass


class ControllerResolverInterface(ContainerAwareInterface):
    def get_controller_and_arguments(self, request):
        raise Exception('Method needs to be implemented')


class ControllerResolver(ControllerResolverInterface):
    def _translate_target(self, target):
        if callable(target):
            return target
        else:
            class_path = target.split(':')
            controller = getattr(importlib.import_module(class_path[0]), class_path[1])

            if len(class_path) != 3:
                if not callable(controller):
                    raise Exception("Cannot resolve callable from target name %s" % target)
                else:
                    return controller()
            else:
                controller = controller()
                controller.set_container(self.get_container())
                return getattr(controller, class_path[2])

    def get_controller_and_arguments(self, request):
        url_matcher = self.get('kodi.url_matcher')

        try:
            route, kwargs = url_matcher.match(request._path)
            print route, kwargs
            fn = self._translate_target(route['target'])
            return (fn, kwargs)
        except:
            return (None, None)