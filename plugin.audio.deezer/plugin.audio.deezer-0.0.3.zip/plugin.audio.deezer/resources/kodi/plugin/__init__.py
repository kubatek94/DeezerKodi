from kodi.app import App
from kodi import xbmcplugin

class AppPlugin(App):
    def handle(self, request):
        kernel = self.container.get_service('kodi.kernel')
        return kernel.handle(request)

    def terminate(self, request, response):
        App.terminate(self, request, response)
        xbmcplugin.endOfDirectory(request.get_id(), succeeded=response.is_success())