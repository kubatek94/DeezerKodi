from events import KernelEvents, GetResponseEvent, FilterResponseEvent, FilterControllerAndArgumentsEvent
from responses import ControllerNotFoundError
from service import Service


class Kernel(Service):
    def __init__(self, event_dispatcher, controller_resolver):
        self._event_dispatcher = event_dispatcher
        self._controller_resolver = controller_resolver

    def handle(self, request):
        event = GetResponseEvent(self, request)
        self._event_dispatcher.dispatch(KernelEvents.REQUEST, event)

        # decide if we should handle the request further
        if event.has_response():
            return self._filter_response(request, event.get_response())

        # get the controller callable
        (controller, arguments) = self._controller_resolver.get_controller_and_arguments(request)
        if controller is None:
            return ControllerNotFoundError(request)

        # allow to modify the controller and arguments in the event handlers
        event = FilterControllerAndArgumentsEvent(self, request, controller, arguments)
        self._event_dispatcher.dispatch(KernelEvents.CONTROLLER_AND_ARGUMENTS, event)
        controller = event.get_controller()
        arguments = event.get_arguments()

        # get the response from controller
        response = controller(**arguments)

        # allow to modify the response
        return self._filter_response(request, response)

    def _filter_response(self, request, response):
        event = FilterResponseEvent(self, request, response)
        self._event_dispatcher.dispatch(KernelEvents.RESPONSE, event)
        return event.get_response()
