import cPickle as pickle
import os.path
import time

from kodi import xbmc
from service import Service


class FileCache(Service):
    TTL = 60 * 60  # 1 hour ttl

    def __init__(self, name):
        self.dirty = False
        self.name = xbmc.translatePath("special://temp/%s.p" % name)
        self.epoch = time.time()

        if os.path.isfile(self.name):
            self.file = open(self.name, 'r+b')
            self.cache = pickle.load(self.file)
        else:
            self.file = open(self.name, 'r+b')
            self.cache = {}

    def set(self, key, value, ttl=TTL):
        self.dirty = True
        self.cache[key.lower()] = {'time': self.epoch, 'ttl': ttl, 'value': value}

    def has(self, key):
        key = key.lower()
        if key not in self.cache:
            return False
        else:
            item = self.cache[key]
            # if item lives longer than ttl allows, remove it from cache
            if (item['time'] + item['ttl']) > self.epoch:
                del self.cache[key]
                return False
            else:
                return True

    def get(self, key, default_value=None, default_producer=None, ttl=TTL):
        if self.has(key):
            return self.cache[key]['value']
        if default_producer is not None:
            product = default_producer()
            self.set(key, product, ttl)
            return product
        return default_value

    def _stop(self):
        if self.dirty:
            pickle.dump(self.cache, self.file, protocol=-1) #-1 will choose fastest version supported
