import importlib
import yaml

class Config(dict):
    def __init__(self, *args, **kwargs):
        super(Config, self).__init__(*args, **kwargs)

    @classmethod
    def merge(cls, a, b):
        if isinstance(a, dict):
            for k, v in b.iteritems():
                a[k] = v if k not in a else Config.merge(a[k], v)
            return a
        elif isinstance(a, list):
            a.extend(b)
            return a
        else:
            return b


class ConfigLoader(object):
    def __init__(self, app):
        self.app = app

    def load_config(self, *args):
        pass


class YamlConfigLoader(ConfigLoader):
    def load_config(self, path):
        try:
            with open(path, 'r') as f:
                config = yaml.load(f)
                return Config(config if config else {})
        except Exception as e:
            print e
            raise Exception('Cannot load config from: %s' % path)


class AppConfigLoader(ConfigLoader):
    def load_config(self, resources):
        app = self.app

        # import each bundle and get its config
        bundle_modules = map(importlib.import_module, resources.bundles)
        configs = map(lambda bundle_module: bundle_module.get_config(app), bundle_modules)

        #reduce all the configs into a single global config
        #and return together with a list of bundles
        return (
            reduce(Config.merge, configs, Config()),
            bundle_modules
        )