from kodi.response import Response
from kodi import xbmc


class ControllerNotFoundError(Response):
    def __init__(self, request):
        super(ControllerNotFoundError, self).__init__()
        self._request = request
        self._success = False

    def send(self):
        xbmc.log("Controller for path %s not found!" % self._request.get_path(), xbmc.LOGERROR)
