class ListItem(object):
    def __init__(self, label, label2=None, iconImage=None, thumbnailImage=None, path=None):
        pass

    def setArt(self, art):
        pass