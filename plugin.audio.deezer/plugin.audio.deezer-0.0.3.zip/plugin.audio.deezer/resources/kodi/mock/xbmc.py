import logging
import sys
import urlparse
logging.basicConfig(stream=sys.stdout, level=logging.INFO, format="%(levelname)s: %(message)s")

LOGDEBUG = logging.DEBUG
LOGERROR = logging.ERROR
LOGFATAL = logging.FATAL
LOGINFO = logging.INFO
LOGNONE = logging.NOTSET
LOGNOTICE = logging.INFO
LOGSEVERE = logging.CRITICAL
LOGWARNING = logging.WARNING

def log(msg, level=LOGNOTICE):
    logging.log(level, msg)

def executebuiltin(command):
    log("Execute built-in: %s" % command)

def notify(msg):
    executebuiltin('notify:%s' % msg)

def translatePath(path):
    return urlparse.urlparse(path).path