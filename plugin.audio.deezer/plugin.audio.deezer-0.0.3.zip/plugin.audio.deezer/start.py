import sys
from resources.lib.Scenes.SceneRouter import SceneRouter

scene_router = SceneRouter()
scene_router.route(sys.argv)

del scene_router
